PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                file_type TEXT NOT NULL,
                upload_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                file_size_bytes INTEGER,
                processed_timestamp TIMESTAMP,
                processing_status TEXT DEFAULT 'pending',
                confidence_score REAL,
                metadata TEXT,
                UNIQUE(filename, upload_timestamp)
            );
INSERT INTO sources VALUES(2,'TakingCare_Benevity_Synthetic_Data.xlsx','xlsx','2025-08-07 16:14:09',9742,'2025-08-07 16:14:49','completed',NULL,NULL);
INSERT INTO sources VALUES(3,'TakingCare_Carbon_Reporting_Synthetic_Data.xlsx','xlsx','2025-08-07 16:16:04',8852,'2025-08-07 16:17:00','completed',NULL,NULL);
INSERT INTO sources VALUES(4,'TakingCare_EAP_Synthetic_Data.xlsx','xlsx','2025-08-07 16:17:55',9639,'2025-08-07 16:18:31','completed',NULL,NULL);
INSERT INTO sources VALUES(5,'TakingCare_EcoVadis_Synthetic_Data.xlsx','xlsx','2025-08-07 16:18:40',9772,'2025-08-07 16:19:21','completed',NULL,NULL);
INSERT INTO sources VALUES(6,'TakingCare_HCM_Synthetic_Data.xlsx','xlsx','2025-08-07 16:19:55',10314,'2025-08-07 16:20:47','completed',NULL,NULL);
INSERT INTO sources VALUES(7,'TakingCare_ITAsset_Environmental_Synthetic_Data.xlsx','xlsx','2025-08-07 16:23:22',9678,'2025-08-07 16:23:58','completed',NULL,NULL);
INSERT INTO sources VALUES(8,'TakingCare_LMS_Synthetic_Data.xlsx','xlsx','2025-08-07 16:25:23',9533,'2025-08-07 16:26:04','completed',NULL,NULL);
INSERT INTO sources VALUES(9,'TakingCare_Payroll_Synthetic_Data.xlsx','xlsx','2025-08-07 16:26:19',9577,'2025-08-07 16:26:59','completed',NULL,NULL);
INSERT INTO sources VALUES(10,'TakingCare_myday_Synthetic_Data.xlsx','xlsx','2025-08-07 16:27:19',9639,'2025-08-07 16:28:06','completed',NULL,NULL);
INSERT INTO sources VALUES(11,'TakingCare_SupplyChain_Synthetic_Data.xlsx','xlsx','2025-08-07 16:29:18',9515,'2025-08-07 16:29:59','completed',NULL,NULL);
INSERT INTO sources VALUES(12,'TakingCare_SurveyEngagement_Synthetic_Data.xlsx','xlsx','2025-08-07 16:31:49',9438,'2025-08-07 16:32:24','completed',NULL,NULL);
INSERT INTO sources VALUES(13,'TakingCare_Payroll_Synthetic_Data.xlsx','xlsx','2025-08-07 23:06:39',9577,'2025-08-07 23:07:15','completed',NULL,NULL);
CREATE TABLE frameworks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                version TEXT,
                description TEXT,
                category TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
INSERT INTO frameworks VALUES(1,'UK Social Value Model','2.0','UK Social Value Model for measuring community impact','government','2025-08-07 15:43:55');
INSERT INTO frameworks VALUES(2,'UN Sustainable Development Goals','2015','United Nations 17 Sustainable Development Goals','international','2025-08-07 15:43:55');
INSERT INTO frameworks VALUES(3,'TOMs (Themes, Outcomes, Measures)','3.0','National TOMs framework for social value measurement','government','2025-08-07 15:43:55');
INSERT INTO frameworks VALUES(4,'B Corp Assessment','6.0','B Corporation impact assessment framework','certification','2025-08-07 15:43:55');
INSERT INTO frameworks VALUES(5,'MAC (Measurement Advisory Council)','1.0','Social value measurement advisory framework','advisory','2025-08-07 15:43:55');
CREATE TABLE impact_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL,
                metric_name TEXT NOT NULL,
                metric_value REAL NOT NULL,
                metric_unit TEXT,
                metric_category TEXT,
                timestamp TIMESTAMP,
                extraction_confidence REAL,
                context_description TEXT,
                raw_text TEXT,
                
                -- Enhanced citation fields for precise source tracking
                source_sheet_name TEXT,
                source_column_name TEXT,
                source_column_index INTEGER,
                source_row_index INTEGER,
                source_cell_reference TEXT,
                source_formula TEXT,
                
                -- Verification and accuracy fields
                verification_status TEXT DEFAULT 'pending',  -- pending, verified, failed, skipped
                verification_timestamp TIMESTAMP,
                verified_value REAL,
                verification_accuracy REAL,  -- 0.0 to 1.0
                verification_notes TEXT,
                
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (source_id) REFERENCES sources (id) ON DELETE CASCADE
            );
INSERT INTO impact_metrics VALUES(1,1,'total_scope_1_emissions',65.59000000000000341,'tCO2e','environmental_impact',NULL,0.6999999999999999556,'Sum of all Scope 1 Emissions',NULL,'Sheet1','Scope 1 Emissions (tCO2e)',1,NULL,'B2:B4','SUM(B2:B4)','verified','2025-08-07 15:44:56',65.59000000000000341,1.0,'Verified using range B2:B4: 65.59 ≈ 65.59','2025-08-07 15:44:55');
INSERT INTO impact_metrics VALUES(2,1,'total_scope_2_emissions',39.14000000000000056,'tCO2e','environmental_impact',NULL,0.6999999999999999556,'Sum of all Scope 2 Emissions',NULL,'Sheet1','Scope 2 Emissions (tCO2e)',2,NULL,'C2:C4','SUM(C2:C4)','verified','2025-08-07 15:44:56',39.14000000000000056,1.0,'Verified using range C2:C4: 39.14 ≈ 39.14','2025-08-07 15:44:56');
INSERT INTO impact_metrics VALUES(3,1,'total_scope_3_emissions',714.2699999999999819,'tCO2e','environmental_impact',NULL,0.6999999999999999556,'Sum of all Scope 3 Emissions',NULL,'Sheet1','Scope 3 Emissions (tCO2e)',3,NULL,'D2:D4','SUM(D2:D4)','verified','2025-08-07 15:44:56',714.2699999999999819,1.0,'Verified using range D2:D4: 714.27 ≈ 714.27','2025-08-07 15:44:56');
INSERT INTO impact_metrics VALUES(4,1,'total_energy_consumption',502390.5,'kWh','environmental_impact',NULL,0.6999999999999999556,'Sum of all Energy Consumption',NULL,'Sheet1','Energy Consumption (kWh)',4,NULL,'E2:E4','SUM(E2:E4)','verified','2025-08-07 15:44:56',502390.5,1.0,'Verified using range E2:E4: 502390.5 ≈ 502390.5','2025-08-07 15:44:56');
INSERT INTO impact_metrics VALUES(5,1,'average_renewable_energy_used',95.9666666666666543,'percent','environmental_impact',NULL,0.6999999999999999556,'Average of Renewable Energy Used',NULL,'Sheet1','Renewable Energy Used (%)',5,NULL,'F2:F4','AVERAGE(F2:F4)','verified','2025-08-07 16:09:32',95.9666666666666543,1.0,'Verified AVERAGE using range F2:F4: calculated=95.9667 ≈ reported=95.96666666666665','2025-08-07 15:44:56');
INSERT INTO impact_metrics VALUES(6,1,'total_carbon_offset_purchased',51.50999999999999802,'tCO2e','environmental_impact',NULL,0.6999999999999999556,'Sum of all Carbon Offset Purchased',NULL,'Sheet1','Carbon Offset Purchased (tCO2e)',6,NULL,'G2:G4','SUM(G2:G4)','verified','2025-08-07 15:44:56',51.50999999999999802,1.0,'Verified using range G2:G4: 51.51 ≈ 51.51','2025-08-07 15:44:56');
INSERT INTO impact_metrics VALUES(7,1,'average_carbon_intensity',6.993333333333333179,'tCO2e/FTE','environmental_impact',NULL,0.6999999999999999556,'Average of Carbon Intensity',NULL,'Sheet1','Carbon Intensity (tCO2e/FTE)',7,NULL,'H2:H4','AVERAGE(H2:H4)','verified','2025-08-07 16:09:32',6.993333333333333179,1.0,'Verified AVERAGE using range H2:H4: calculated=6.9933 ≈ reported=6.993333333333333','2025-08-07 15:44:56');
INSERT INTO impact_metrics VALUES(8,2,'total_volunteering_hours',287.0,'hours','community_engagement',NULL,0.6999999999999999556,'Sum of all volunteering hours',NULL,'Sheet1','Total Volunteering Hours',4,NULL,'E2:E16','SUM(E2:E16)','verified','2025-08-07 16:35:50',287.0,1.0,'Verified SUM using range E2:E16: calculated=287.0000 ≈ reported=287.0','2025-08-07 16:14:49');
INSERT INTO impact_metrics VALUES(9,2,'total_donations',4023.119999999999437,'GBP','charitable_giving',NULL,0.6999999999999999556,'Sum of all donations',NULL,'Sheet1','Total Donations (£)',3,NULL,'D2:D16','SUM(D2:D16)','verified','2025-08-07 16:35:50',4023.119999999999437,1.0,'Verified SUM using range D2:D16: calculated=4023.1200 ≈ reported=4023.1199999999994','2025-08-07 16:14:49');
INSERT INTO impact_metrics VALUES(10,2,'total_matching_contributions',2011.570000000000164,'GBP','charitable_giving',NULL,0.6999999999999999556,'Sum of all matching contributions',NULL,'Sheet1','Matching Contributions (£)',7,NULL,'H2:H16','SUM(H2:H16)','verified','2025-08-07 16:35:50',2011.570000000000164,1.0,'Verified SUM using range H2:H16: calculated=2011.5700 ≈ reported=2011.5700000000002','2025-08-07 16:14:49');
INSERT INTO impact_metrics VALUES(11,2,'total_campaigns_joined',45.0,'count','community_engagement',NULL,0.6999999999999999556,'Sum of all campaigns joined',NULL,'Sheet1','Number of Campaigns Joined',5,NULL,'F2:F16','SUM(F2:F16)','verified','2025-08-07 16:35:50',45.0,1.0,'Verified SUM using range F2:F16: calculated=45.0000 ≈ reported=45.0','2025-08-07 16:14:49');
INSERT INTO impact_metrics VALUES(12,3,'total_scope_1_emissions',65.59000000000000341,'tCO2e','environmental_impact',NULL,0.6999999999999999556,'Sum of all Scope 1 Emissions',NULL,'Sheet1','Scope 1 Emissions (tCO2e)',1,NULL,'B2:B4','SUM(B2:B4)','verified','2025-08-07 16:35:50',65.59000000000000341,1.0,'Verified SUM using range B2:B4: calculated=65.5900 ≈ reported=65.59','2025-08-07 16:17:00');
INSERT INTO impact_metrics VALUES(13,3,'total_scope_2_emissions',39.14000000000000056,'tCO2e','environmental_impact',NULL,0.6999999999999999556,'Sum of all Scope 2 Emissions',NULL,'Sheet1','Scope 2 Emissions (tCO2e)',2,NULL,'C2:C4','SUM(C2:C4)','verified','2025-08-07 16:35:50',39.14000000000000056,1.0,'Verified SUM using range C2:C4: calculated=39.1400 ≈ reported=39.14','2025-08-07 16:17:00');
INSERT INTO impact_metrics VALUES(14,3,'total_scope_3_emissions',714.2699999999999819,'tCO2e','environmental_impact',NULL,0.6999999999999999556,'Sum of all Scope 3 Emissions',NULL,'Sheet1','Scope 3 Emissions (tCO2e)',3,NULL,'D2:D4','SUM(D2:D4)','verified','2025-08-07 16:35:50',714.2699999999999819,1.0,'Verified SUM using range D2:D4: calculated=714.2700 ≈ reported=714.27','2025-08-07 16:17:00');
INSERT INTO impact_metrics VALUES(15,3,'total_energy_consumption',502390.5,'kWh','environmental_impact',NULL,0.6999999999999999556,'Sum of all Energy Consumption',NULL,'Sheet1','Energy Consumption (kWh)',4,NULL,'E2:E4','SUM(E2:E4)','verified','2025-08-07 16:35:50',502390.5,1.0,'Verified SUM using range E2:E4: calculated=502390.5000 ≈ reported=502390.5','2025-08-07 16:17:00');
INSERT INTO impact_metrics VALUES(16,3,'average_renewable_energy_used',95.9666666666666543,'percent','environmental_impact',NULL,0.6999999999999999556,'Average of Renewable Energy Used',NULL,'Sheet1','Renewable Energy Used (%)',5,NULL,'F2:F4','AVERAGE(F2:F4)','verified','2025-08-07 16:35:50',95.9666666666666543,1.0,'Verified AVERAGE using range F2:F4: calculated=95.9667 ≈ reported=95.96666666666665','2025-08-07 16:17:00');
INSERT INTO impact_metrics VALUES(17,3,'total_carbon_offset_purchased',51.50999999999999802,'tCO2e','environmental_impact',NULL,0.6999999999999999556,'Sum of all Carbon Offset Purchased',NULL,'Sheet1','Carbon Offset Purchased (tCO2e)',6,NULL,'G2:G4','SUM(G2:G4)','verified','2025-08-07 16:35:50',51.50999999999999802,1.0,'Verified SUM using range G2:G4: calculated=51.5100 ≈ reported=51.51','2025-08-07 16:17:00');
INSERT INTO impact_metrics VALUES(18,3,'average_carbon_intensity',6.993333333333333179,'tCO2e/FTE','environmental_impact',NULL,0.6999999999999999556,'Average of Carbon Intensity',NULL,'Sheet1','Carbon Intensity (tCO2e/FTE)',7,NULL,'H2:H4','AVERAGE(H2:H4)','verified','2025-08-07 16:35:50',6.993333333333333179,1.0,'Verified AVERAGE using range H2:H4: calculated=6.9933 ≈ reported=6.993333333333333','2025-08-07 16:17:00');
INSERT INTO impact_metrics VALUES(19,4,'total_sessions_accessed',75.0,'sessions','health_wellbeing',NULL,0.6999999999999999556,'Sum of all sessions accessed',NULL,'Sheet1','Total Sessions Accessed',3,NULL,'D2:D16','SUM(D2:D16)','verified','2025-08-07 16:35:50',75.0,1.0,'Verified SUM using range D2:D16: calculated=75.0000 ≈ reported=75.0','2025-08-07 16:18:30');
INSERT INTO impact_metrics VALUES(20,5,'average_overall_score',60.82857142857142919,'score','social_value_composite',NULL,0.6999999999999999556,'Average of overall scores',NULL,'Sheet1','Overall Score',3,NULL,'D2:D16','AVERAGE(D2:D16)','verified','2025-08-07 16:35:50',60.82857142857142919,1.0,'Verified AVERAGE using range D2:D16: calculated=60.8286 ≈ reported=60.82857142857143','2025-08-07 16:19:20');
INSERT INTO impact_metrics VALUES(21,5,'average_environment_score',62.15333333333333599,'score','environmental_impact',NULL,0.6999999999999999556,'Average of environment scores',NULL,'Sheet1','Environment Score',4,NULL,'E2:E16','AVERAGE(E2:E16)','verified','2025-08-07 16:35:50',62.15333333333333599,1.0,'Verified AVERAGE using range E2:E16: calculated=62.1533 ≈ reported=62.153333333333336','2025-08-07 16:19:21');
INSERT INTO impact_metrics VALUES(22,5,'average_labor_human_rights_score',63.33333333333333571,'score','employment',NULL,0.6999999999999999556,'Average of labor & human rights scores',NULL,'Sheet1','Labor & Human Rights Score',5,NULL,'F2:F16','AVERAGE(F2:F16)','verified','2025-08-07 16:35:50',63.33333333333333571,1.0,'Verified AVERAGE using range F2:F16: calculated=63.3333 ≈ reported=63.333333333333336','2025-08-07 16:19:21');
INSERT INTO impact_metrics VALUES(23,5,'average_ethics_score',61.48666666666666458,'score','employment',NULL,0.6999999999999999556,'Average of ethics scores',NULL,'Sheet1','Ethics Score',6,NULL,'G2:G16','AVERAGE(G2:G16)','verified','2025-08-07 16:35:50',61.48666666666666458,1.0,'Verified AVERAGE using range G2:G16: calculated=61.4867 ≈ reported=61.486666666666665','2025-08-07 16:19:21');
INSERT INTO impact_metrics VALUES(24,5,'average_sustainable_procurement_score',60.47999999999999688,'score','procurement',NULL,0.6999999999999999556,'Average of sustainable procurement scores',NULL,'Sheet1','Sustainable Procurement Score',7,NULL,'H2:H16','AVERAGE(H2:H16)','verified','2025-08-07 16:35:50',60.47999999999999688,1.0,'Verified AVERAGE using range H2:H16: calculated=60.4800 ≈ reported=60.48','2025-08-07 16:19:21');
INSERT INTO impact_metrics VALUES(25,6,'total_voluntary_hours',184.0,'hours','community_engagement',NULL,0.6999999999999999556,'Sum of all voluntary hours',NULL,'Sheet1','Voluntary Hours',16,NULL,'Q2:Q16','SUM(Q2:Q16)','verified','2025-08-07 16:35:50',184.0,1.0,'Verified SUM using range Q2:Q16: calculated=184.0000 ≈ reported=184.0','2025-08-07 16:20:46');
INSERT INTO impact_metrics VALUES(26,6,'average_voluntary_hours',12.2666666666666675,'hours','community_engagement',NULL,0.6999999999999999556,'Average voluntary hours per person',NULL,'Sheet1','Voluntary Hours',16,NULL,'Q2:Q16','AVERAGE(Q2:Q16)','verified','2025-08-07 16:35:50',12.2666666666666675,1.0,'Verified AVERAGE using range Q2:Q16: calculated=12.2667 ≈ reported=12.266666666666667','2025-08-07 16:20:47');
INSERT INTO impact_metrics VALUES(27,6,'total_training_hours',263.0,'hours','employment',NULL,0.6999999999999999556,'Sum of all training hours',NULL,'Sheet1','Training Hours',15,NULL,'P2:P16','SUM(P2:P16)','verified','2025-08-07 16:35:50',263.0,1.0,'Verified SUM using range P2:P16: calculated=263.0000 ≈ reported=263.0','2025-08-07 16:20:47');
INSERT INTO impact_metrics VALUES(28,6,'average_training_hours',17.533333333333335,'hours','employment',NULL,0.6999999999999999556,'Average training hours per person',NULL,'Sheet1','Training Hours',15,NULL,'P2:P16','AVERAGE(P2:P16)','verified','2025-08-07 16:35:50',17.533333333333335,1.0,'Verified AVERAGE using range P2:P16: calculated=17.5333 ≈ reported=17.533333333333335','2025-08-07 16:20:47');
INSERT INTO impact_metrics VALUES(29,6,'total_absence_days',137.0,'days','health_wellbeing',NULL,0.6999999999999999556,'Sum of all absence days',NULL,'Sheet1','Absences (days)',14,NULL,'O2:O16','SUM(O2:O16)','verified','2025-08-07 16:35:50',137.0,1.0,'Verified SUM using range O2:O16: calculated=137.0000 ≈ reported=137.0','2025-08-07 16:20:47');
INSERT INTO impact_metrics VALUES(30,6,'average_absence_days',9.13333333333333286,'days','health_wellbeing',NULL,0.6999999999999999556,'Average absence days per person',NULL,'Sheet1','Absences (days)',14,NULL,'O2:O16','AVERAGE(O2:O16)','verified','2025-08-07 16:35:50',9.13333333333333286,1.0,'Verified AVERAGE using range O2:O16: calculated=9.1333 ≈ reported=9.133333333333333','2025-08-07 16:20:47');
INSERT INTO impact_metrics VALUES(31,6,'total_annual_salary',268000.0,'GBP','employment',NULL,0.6999999999999999556,'Sum of all annual salaries',NULL,'Sheet1','Annual Salary (£)',12,NULL,'M2:M16','SUM(M2:M16)','verified','2025-08-07 16:35:50',268000.0,1.0,'Verified SUM using range M2:M16: calculated=268000.0000 ≈ reported=268000.0','2025-08-07 16:20:47');
INSERT INTO impact_metrics VALUES(32,6,'average_annual_salary',17866.66666666666787,'GBP','employment',NULL,0.6999999999999999556,'Average annual salary per person',NULL,'Sheet1','Annual Salary (£)',12,NULL,'M2:M16','AVERAGE(M2:M16)','verified','2025-08-07 16:35:50',17866.66666666666787,1.0,'Verified AVERAGE using range M2:M16: calculated=17866.6667 ≈ reported=17866.666666666668','2025-08-07 16:20:47');
INSERT INTO impact_metrics VALUES(33,7,'total_carbon_saving',371.5000000000000568,'kg CO2e','environmental_impact',NULL,0.6999999999999999556,'Sum of all carbon savings',NULL,'Sheet1','Carbon Saving (kg CO2e)',9,NULL,'J2:J16','SUM(J2:J16)','verified','2025-08-07 16:35:50',371.5000000000000568,1.0,'Verified SUM using range J2:J16: calculated=371.5000 ≈ reported=371.50000000000006','2025-08-07 16:23:57');
INSERT INTO impact_metrics VALUES(34,7,'count_reused_or_redeployed',5.0,'count','environmental_impact',NULL,0.6999999999999999556,'Count of reused or redeployed assets',NULL,'Sheet1','Reuse / Redeployed?',6,NULL,'G1',NULL,'failed','2025-08-07 16:35:50',NULL,0.0,'Value mismatch in cell G1: actual=nan, reported=5.0','2025-08-07 16:23:57');
INSERT INTO impact_metrics VALUES(35,7,'count_recycled_assets',7.0,'count','environmental_impact',NULL,0.6999999999999999556,'Count of recycled assets',NULL,'Sheet1','Recycled (Y/N)',7,NULL,'H1',NULL,'failed','2025-08-07 16:35:50',NULL,0.0,'Value mismatch in cell H1: actual=nan, reported=7.0','2025-08-07 16:23:57');
INSERT INTO impact_metrics VALUES(36,8,'total_courses_completed',104.0,'courses','employment',NULL,0.6999999999999999556,'Sum of all courses completed',NULL,'Sheet1','Courses Completed',3,NULL,'D2:D16','SUM(D2:D16)','verified','2025-08-07 16:35:50',104.0,1.0,'Verified SUM using range D2:D16: calculated=104.0000 ≈ reported=104.0','2025-08-07 16:26:04');
INSERT INTO impact_metrics VALUES(37,8,'average_mandatory_training_completion',84.47333333333332917,'percent','employment',NULL,0.6999999999999999556,'Average mandatory training completion rate',NULL,'Sheet1','Mandatory Training Completed (%)',4,NULL,'E2:E16','AVERAGE(E2:E16)','verified','2025-08-07 16:35:50',84.47333333333332917,1.0,'Verified AVERAGE using range E2:E16: calculated=84.4733 ≈ reported=84.47333333333333','2025-08-07 16:26:04');
INSERT INTO impact_metrics VALUES(38,8,'total_social_value_modules_completed',20.0,'modules','employment',NULL,0.6999999999999999556,'Sum of all social value modules completed',NULL,'Sheet1','Social Value Modules Completed',5,NULL,'F2:F16','SUM(F2:F16)','verified','2025-08-07 16:35:50',20.0,1.0,'Verified SUM using range F2:F16: calculated=20.0000 ≈ reported=20.0','2025-08-07 16:26:04');
INSERT INTO impact_metrics VALUES(39,8,'total_learning_hours',592.0,'hours','employment',NULL,0.6999999999999999556,'Sum of all learning hours',NULL,'Sheet1','Total Learning Hours',6,NULL,'G2:G16','SUM(G2:G16)','verified','2025-08-07 16:35:50',592.0,1.0,'Verified SUM using range G2:G16: calculated=592.0000 ≈ reported=592.0','2025-08-07 16:26:04');
INSERT INTO impact_metrics VALUES(40,8,'certifications_earned_count',12.0,'certifications','employment',NULL,0.6999999999999999556,'Count of certifications earned',NULL,'Sheet1','Certification Earned',8,NULL,'I1',NULL,'failed','2025-08-07 16:35:50',NULL,0.0,'Value mismatch in cell I1: actual=nan, reported=12.0','2025-08-07 16:26:04');
INSERT INTO impact_metrics VALUES(41,8,'average_completion_rate',80.14000000000001477,'percent','employment',NULL,0.6999999999999999556,'Average completion rate',NULL,'Sheet1','Completion Rate (%)',9,NULL,'J2:J16','AVERAGE(J2:J16)','verified','2025-08-07 16:35:50',80.14000000000001477,1.0,'Verified AVERAGE using range J2:J16: calculated=80.1400 ≈ reported=80.14000000000001','2025-08-07 16:26:04');
INSERT INTO impact_metrics VALUES(42,9,'total_charity_donations',2370.550000000000181,'GBP','charitable_giving',NULL,0.6999999999999999556,'Sum of all charity donations via payroll',NULL,'Sheet1','Charity Donations via Payroll (£)',5,NULL,'F2:F16','SUM(F2:F16)','verified','2025-08-07 16:35:50',2370.550000000000181,1.0,'Verified SUM using range F2:F16: calculated=2370.5500 ≈ reported=2370.55','2025-08-07 16:26:58');
INSERT INTO impact_metrics VALUES(43,9,'average_charity_donation',158.0366666666666902,'GBP','charitable_giving',NULL,0.6999999999999999556,'Average charity donation via payroll',NULL,'Sheet1','Charity Donations via Payroll (£)',5,NULL,'F2:F16','AVERAGE(F2:F16)','verified','2025-08-07 16:35:50',158.0366666666666902,1.0,'Verified AVERAGE using range F2:F16: calculated=158.0367 ≈ reported=158.0366666666667','2025-08-07 16:26:59');
INSERT INTO impact_metrics VALUES(44,9,'total_overtime_hours',644.0,'hours','employment',NULL,0.6999999999999999556,'Sum of all overtime hours',NULL,'Sheet1','Overtime Hours',8,NULL,'I2:I16','SUM(I2:I16)','verified','2025-08-07 16:35:50',644.0,1.0,'Verified SUM using range I2:I16: calculated=644.0000 ≈ reported=644.0','2025-08-07 16:26:59');
INSERT INTO impact_metrics VALUES(45,9,'average_gender_pay_gap',-0.0933333333333328796,'percent','employment',NULL,0.6999999999999999556,'Average gender pay gap',NULL,'Sheet1','Gender Pay Gap (%)',9,NULL,'J2:J16','AVERAGE(J2:J16)','verified','2025-08-07 16:35:50',-0.0933333333333328796,1.0,'Verified AVERAGE using range J2:J16: calculated=-0.0933 ≈ reported=-0.09333333333333288','2025-08-07 16:26:59');
INSERT INTO impact_metrics VALUES(46,9,'total_gross_pay',382000.0,'GBP','employment',NULL,0.6999999999999999556,'Sum of all gross pay',NULL,'Sheet1','Gross Pay (£)',3,NULL,'D2:D16','SUM(D2:D16)','verified','2025-08-07 16:35:50',382000.0,1.0,'Verified SUM using range D2:D16: calculated=382000.0000 ≈ reported=382000.0','2025-08-07 16:26:59');
INSERT INTO impact_metrics VALUES(47,9,'total_pension_contributions',19100.0,'GBP','employment',NULL,0.6999999999999999556,'Sum of all pension contributions',NULL,'Sheet1','Pension Contributions (£)',6,NULL,'G2:G16','SUM(G2:G16)','verified','2025-08-07 16:35:50',19100.0,1.0,'Verified SUM using range G2:G16: calculated=19100.0000 ≈ reported=19100.0','2025-08-07 16:26:59');
INSERT INTO impact_metrics VALUES(48,10,'total_checkins_completed',325.0,'check-ins','health_wellbeing',NULL,0.6999999999999999556,'Sum of all check-ins completed',NULL,'Sheet1','Check-ins Completed',4,NULL,'E2:E16','SUM(E2:E16)','verified','2025-08-07 16:35:50',325.0,1.0,'Verified SUM using range E2:E16: calculated=325.0000 ≈ reported=325.0','2025-08-07 16:28:05');
INSERT INTO impact_metrics VALUES(49,10,'average_wellbeing_score',6.566666666666667317,'score','health_wellbeing',NULL,0.6999999999999999556,'Average wellbeing score',NULL,'Sheet1','Wellbeing Score (avg)',6,NULL,'G2:G16','AVERAGE(G2:G16)','verified','2025-08-07 16:35:50',6.566666666666667317,1.0,'Verified AVERAGE using range G2:G16: calculated=6.5667 ≈ reported=6.566666666666667','2025-08-07 16:28:06');
INSERT INTO impact_metrics VALUES(50,10,'unique_charities_unlocked',5.0,'charity','charitable_giving',NULL,0.6999999999999999556,'Count of unique charities unlocked',NULL,'Sheet1','Charity Unlocked',7,NULL,'H1',NULL,'failed','2025-08-07 16:35:50',NULL,0.0,'Value mismatch in cell H1: actual=nan, reported=5.0','2025-08-07 16:28:06');
INSERT INTO impact_metrics VALUES(51,10,'total_care_pathways_followed',36.0,'pathways','health_wellbeing',NULL,0.6999999999999999556,'Sum of all care pathways followed',NULL,'Sheet1','Care Pathways Followed',5,NULL,'F2:F16','SUM(F2:F16)','verified','2025-08-07 16:35:50',36.0,1.0,'Verified SUM using range F2:F16: calculated=36.0000 ≈ reported=36.0','2025-08-07 16:28:06');
INSERT INTO impact_metrics VALUES(52,11,'total_spend',419720.3699999999954,'GBP','procurement',NULL,0.6999999999999999556,'Sum of all spend',NULL,'Sheet1','Total Spend (£)',3,NULL,'D2:D16','SUM(D2:D16)','verified','2025-08-07 16:35:50',419720.3699999999954,1.0,'Verified SUM using range D2:D16: calculated=419720.3700 ≈ reported=419720.37','2025-08-07 16:29:59');
INSERT INTO impact_metrics VALUES(53,11,'proportion_local_suppliers',0.5333333333333333259,'proportion','procurement',NULL,0.6999999999999999556,'Proportion of local suppliers',NULL,'Sheet1','Local Supplier?',6,NULL,'G1',NULL,'failed','2025-08-07 16:35:50',NULL,0.0,'Value mismatch in cell G1: actual=nan, reported=0.5333333333333333','2025-08-07 16:29:59');
INSERT INTO impact_metrics VALUES(54,11,'proportion_sme_suppliers',0.5999999999999999778,'proportion','procurement',NULL,0.6999999999999999556,'Proportion of SME suppliers',NULL,'Sheet1','SME Status',4,NULL,'E1',NULL,'failed','2025-08-07 16:35:50',NULL,0.0,'Value mismatch in cell E1: actual=nan, reported=0.6','2025-08-07 16:29:59');
INSERT INTO impact_metrics VALUES(55,11,'proportion_vcse_suppliers',0.4666666666666666741,'proportion','procurement',NULL,0.6999999999999999556,'Proportion of VCSE suppliers',NULL,'Sheet1','VCSE Status',5,NULL,'F1',NULL,'failed','2025-08-07 16:35:50',NULL,0.0,'Value mismatch in cell F1: actual=nan, reported=0.4666666666666667','2025-08-07 16:29:59');
INSERT INTO impact_metrics VALUES(56,11,'proportion_ethical_audit_passed',0.5999999999999999778,'proportion','procurement',NULL,0.6999999999999999556,'Proportion of suppliers that passed the ethical audit',NULL,'Sheet1','Ethical Audit Passed',9,NULL,'J1',NULL,'failed','2025-08-07 16:35:50',NULL,0.0,'Value mismatch in cell J1: actual=nan, reported=0.6','2025-08-07 16:29:59');
INSERT INTO impact_metrics VALUES(57,12,'average_inclusion_score',6.866666666666666252,'score','employment',NULL,0.6999999999999999556,'Average inclusion score',NULL,'Sheet1','Inclusion Score (1–10)',3,NULL,'D2:D16','AVERAGE(D2:D16)','verified','2025-08-07 16:35:50',6.866666666666666252,1.0,'Verified AVERAGE using range D2:D16: calculated=6.8667 ≈ reported=6.866666666666666','2025-08-07 16:32:24');
INSERT INTO impact_metrics VALUES(58,12,'average_wellbeing_perception_score',7.466666666666666786,'score','health_wellbeing',NULL,0.6999999999999999556,'Average wellbeing perception score',NULL,'Sheet1','Wellbeing Perception Score (1–10)',4,NULL,'E2:E16','AVERAGE(E2:E16)','verified','2025-08-07 16:35:50',7.466666666666666786,1.0,'Verified AVERAGE using range E2:E16: calculated=7.4667 ≈ reported=7.466666666666667','2025-08-07 16:32:24');
INSERT INTO impact_metrics VALUES(59,12,'average_purpose_alignment_score',5.400000000000000355,'score','employment',NULL,0.6999999999999999556,'Average purpose alignment score',NULL,'Sheet1','Purpose Alignment Score (1–10)',5,NULL,'F2:F16','AVERAGE(F2:F16)','verified','2025-08-07 16:35:50',5.400000000000000355,1.0,'Verified AVERAGE using range F2:F16: calculated=5.4000 ≈ reported=5.4','2025-08-07 16:32:24');
INSERT INTO impact_metrics VALUES(60,12,'average_manager_trust_score',7.466666666666666786,'score','employment',NULL,0.6999999999999999556,'Average manager trust score',NULL,'Sheet1','Manager Trust Score (1–10)',7,NULL,'H2:H16','AVERAGE(H2:H16)','verified','2025-08-07 16:35:50',7.466666666666666786,1.0,'Verified AVERAGE using range H2:H16: calculated=7.4667 ≈ reported=7.466666666666667','2025-08-07 16:32:24');
INSERT INTO impact_metrics VALUES(61,12,'average_esg_awareness_score',6.400000000000000355,'score','environmental_impact',NULL,0.6999999999999999556,'Average ESG awareness score',NULL,'Sheet1','ESG Awareness Score (1–10)',8,NULL,'I2:I16','AVERAGE(I2:I16)','verified','2025-08-07 16:35:50',6.400000000000000355,1.0,'Verified AVERAGE using range I2:I16: calculated=6.4000 ≈ reported=6.4','2025-08-07 16:32:24');
INSERT INTO impact_metrics VALUES(62,13,'total_charity_donations',2370.550000000000181,'GBP','charitable_giving',NULL,0.6999999999999999556,'Sum of all charity donations via payroll',NULL,'Sheet1','Charity Donations via Payroll (£)',5,NULL,'F2:F15','SUM(F2:F15)','pending',NULL,NULL,NULL,NULL,'2025-08-07 23:07:15');
INSERT INTO impact_metrics VALUES(63,13,'average_charity_donation',158.0366666666666902,'GBP','charitable_giving',NULL,0.6999999999999999556,'Average charity donation via payroll',NULL,'Sheet1','Charity Donations via Payroll (£)',5,NULL,'F2:F15','AVERAGE(F2:F15)','pending',NULL,NULL,NULL,NULL,'2025-08-07 23:07:15');
INSERT INTO impact_metrics VALUES(64,13,'total_gross_pay',382000.0,'GBP','employment',NULL,0.6999999999999999556,'Sum of all gross pay',NULL,'Sheet1','Gross Pay (£)',3,NULL,'D2:D15','SUM(D2:D15)','pending',NULL,NULL,NULL,NULL,'2025-08-07 23:07:15');
INSERT INTO impact_metrics VALUES(65,13,'total_overtime_hours',644.0,'hours','employment',NULL,0.6999999999999999556,'Sum of all overtime hours',NULL,'Sheet1','Overtime Hours',8,NULL,'I2:I15','SUM(I2:I15)','pending',NULL,NULL,NULL,NULL,'2025-08-07 23:07:15');
INSERT INTO impact_metrics VALUES(66,13,'average_gender_pay_gap',-0.0933333333333328796,'percent','employment',NULL,0.6999999999999999556,'Average gender pay gap',NULL,'Sheet1','Gender Pay Gap (%)',9,NULL,'J2:J15','AVERAGE(J2:J15)','pending',NULL,NULL,NULL,NULL,'2025-08-07 23:07:15');
CREATE TABLE commitments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL,
                commitment_text TEXT NOT NULL,
                commitment_type TEXT,
                target_value REAL,
                target_unit TEXT,
                target_date DATE,
                status TEXT DEFAULT 'active',
                confidence_score REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (source_id) REFERENCES sources (id) ON DELETE CASCADE
            );
CREATE TABLE framework_mappings (
                impact_metric_id INTEGER,
                framework_id INTEGER,
                category TEXT,
                
                -- Enhanced framework mapping fields
                framework_name TEXT NOT NULL,
                framework_category TEXT NOT NULL,
                mapping_confidence REAL DEFAULT 0.8,
                mapping_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                
                PRIMARY KEY (impact_metric_id, framework_id),
                FOREIGN KEY (impact_metric_id) REFERENCES impact_metrics(id),
                FOREIGN KEY (framework_id) REFERENCES frameworks(id)
            );
CREATE TABLE embeddings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric_id INTEGER,
                commitment_id INTEGER,
                embedding_vector_id TEXT NOT NULL,
                text_chunk TEXT NOT NULL,
                chunk_type TEXT NOT NULL,
                embedding_model TEXT DEFAULT 'all-MiniLM-L6-v2',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (metric_id) REFERENCES impact_metrics (id) ON DELETE CASCADE,
                FOREIGN KEY (commitment_id) REFERENCES commitments (id) ON DELETE CASCADE,
                CHECK ((metric_id IS NOT NULL AND commitment_id IS NULL) OR 
                       (metric_id IS NULL AND commitment_id IS NOT NULL))
            );
INSERT INTO embeddings VALUES(1,1,NULL,'metric_1','Metric: total_scope_1_emissions Value: 65.59 tCO2e Category: environmental_impact Context: Sum of all Scope 1 Emissions','metric','all-MiniLM-L6-v2','2025-08-07 15:44:56');
INSERT INTO embeddings VALUES(2,2,NULL,'metric_2','Metric: total_scope_2_emissions Value: 39.14 tCO2e Category: environmental_impact Context: Sum of all Scope 2 Emissions','metric','all-MiniLM-L6-v2','2025-08-07 15:44:56');
INSERT INTO embeddings VALUES(3,3,NULL,'metric_3','Metric: total_scope_3_emissions Value: 714.27 tCO2e Category: environmental_impact Context: Sum of all Scope 3 Emissions','metric','all-MiniLM-L6-v2','2025-08-07 15:44:56');
INSERT INTO embeddings VALUES(4,4,NULL,'metric_4','Metric: total_energy_consumption Value: 502390.5 kWh Category: environmental_impact Context: Sum of all Energy Consumption','metric','all-MiniLM-L6-v2','2025-08-07 15:44:56');
INSERT INTO embeddings VALUES(5,5,NULL,'metric_5','Metric: average_renewable_energy_used Value: 95.96666666666665 percent Category: environmental_impact Context: Average of Renewable Energy Used','metric','all-MiniLM-L6-v2','2025-08-07 15:44:56');
INSERT INTO embeddings VALUES(6,6,NULL,'metric_6','Metric: total_carbon_offset_purchased Value: 51.51 tCO2e Category: environmental_impact Context: Sum of all Carbon Offset Purchased','metric','all-MiniLM-L6-v2','2025-08-07 15:44:56');
INSERT INTO embeddings VALUES(7,7,NULL,'metric_7','Metric: average_carbon_intensity Value: 6.993333333333333 tCO2e/FTE Category: environmental_impact Context: Average of Carbon Intensity','metric','all-MiniLM-L6-v2','2025-08-07 15:44:56');
INSERT INTO embeddings VALUES(8,8,NULL,'metric_8','Metric: total_volunteering_hours Value: 287.0 hours Category: community_engagement Context: Sum of all volunteering hours','metric','all-MiniLM-L6-v2','2025-08-07 16:14:49');
INSERT INTO embeddings VALUES(9,9,NULL,'metric_9','Metric: total_donations Value: 4023.1199999999994 GBP Category: charitable_giving Context: Sum of all donations','metric','all-MiniLM-L6-v2','2025-08-07 16:14:49');
INSERT INTO embeddings VALUES(10,10,NULL,'metric_10','Metric: total_matching_contributions Value: 2011.5700000000002 GBP Category: charitable_giving Context: Sum of all matching contributions','metric','all-MiniLM-L6-v2','2025-08-07 16:14:49');
INSERT INTO embeddings VALUES(11,11,NULL,'metric_11','Metric: total_campaigns_joined Value: 45.0 count Category: community_engagement Context: Sum of all campaigns joined','metric','all-MiniLM-L6-v2','2025-08-07 16:14:49');
INSERT INTO embeddings VALUES(12,12,NULL,'metric_12','Metric: total_scope_1_emissions Value: 65.59 tCO2e Category: environmental_impact Context: Sum of all Scope 1 Emissions','metric','all-MiniLM-L6-v2','2025-08-07 16:17:00');
INSERT INTO embeddings VALUES(13,13,NULL,'metric_13','Metric: total_scope_2_emissions Value: 39.14 tCO2e Category: environmental_impact Context: Sum of all Scope 2 Emissions','metric','all-MiniLM-L6-v2','2025-08-07 16:17:00');
INSERT INTO embeddings VALUES(14,14,NULL,'metric_14','Metric: total_scope_3_emissions Value: 714.27 tCO2e Category: environmental_impact Context: Sum of all Scope 3 Emissions','metric','all-MiniLM-L6-v2','2025-08-07 16:17:00');
INSERT INTO embeddings VALUES(15,15,NULL,'metric_15','Metric: total_energy_consumption Value: 502390.5 kWh Category: environmental_impact Context: Sum of all Energy Consumption','metric','all-MiniLM-L6-v2','2025-08-07 16:17:00');
INSERT INTO embeddings VALUES(16,16,NULL,'metric_16','Metric: average_renewable_energy_used Value: 95.96666666666665 percent Category: environmental_impact Context: Average of Renewable Energy Used','metric','all-MiniLM-L6-v2','2025-08-07 16:17:00');
INSERT INTO embeddings VALUES(17,17,NULL,'metric_17','Metric: total_carbon_offset_purchased Value: 51.51 tCO2e Category: environmental_impact Context: Sum of all Carbon Offset Purchased','metric','all-MiniLM-L6-v2','2025-08-07 16:17:00');
INSERT INTO embeddings VALUES(18,18,NULL,'metric_18','Metric: average_carbon_intensity Value: 6.993333333333333 tCO2e/FTE Category: environmental_impact Context: Average of Carbon Intensity','metric','all-MiniLM-L6-v2','2025-08-07 16:17:00');
INSERT INTO embeddings VALUES(19,19,NULL,'metric_19','Metric: total_sessions_accessed Value: 75.0 sessions Category: health_wellbeing Context: Sum of all sessions accessed','metric','all-MiniLM-L6-v2','2025-08-07 16:18:31');
INSERT INTO embeddings VALUES(20,20,NULL,'metric_20','Metric: average_overall_score Value: 60.82857142857143 score Category: social_value_composite Context: Average of overall scores','metric','all-MiniLM-L6-v2','2025-08-07 16:19:21');
INSERT INTO embeddings VALUES(21,21,NULL,'metric_21','Metric: average_environment_score Value: 62.153333333333336 score Category: environmental_impact Context: Average of environment scores','metric','all-MiniLM-L6-v2','2025-08-07 16:19:21');
INSERT INTO embeddings VALUES(22,22,NULL,'metric_22','Metric: average_labor_human_rights_score Value: 63.333333333333336 score Category: employment Context: Average of labor & human rights scores','metric','all-MiniLM-L6-v2','2025-08-07 16:19:21');
INSERT INTO embeddings VALUES(23,23,NULL,'metric_23','Metric: average_ethics_score Value: 61.486666666666665 score Category: employment Context: Average of ethics scores','metric','all-MiniLM-L6-v2','2025-08-07 16:19:21');
INSERT INTO embeddings VALUES(24,24,NULL,'metric_24','Metric: average_sustainable_procurement_score Value: 60.48 score Category: procurement Context: Average of sustainable procurement scores','metric','all-MiniLM-L6-v2','2025-08-07 16:19:21');
INSERT INTO embeddings VALUES(25,25,NULL,'metric_25','Metric: total_voluntary_hours Value: 184.0 hours Category: community_engagement Context: Sum of all voluntary hours','metric','all-MiniLM-L6-v2','2025-08-07 16:20:47');
INSERT INTO embeddings VALUES(26,26,NULL,'metric_26','Metric: average_voluntary_hours Value: 12.266666666666667 hours Category: community_engagement Context: Average voluntary hours per person','metric','all-MiniLM-L6-v2','2025-08-07 16:20:47');
INSERT INTO embeddings VALUES(27,27,NULL,'metric_27','Metric: total_training_hours Value: 263.0 hours Category: employment Context: Sum of all training hours','metric','all-MiniLM-L6-v2','2025-08-07 16:20:47');
INSERT INTO embeddings VALUES(28,28,NULL,'metric_28','Metric: average_training_hours Value: 17.533333333333335 hours Category: employment Context: Average training hours per person','metric','all-MiniLM-L6-v2','2025-08-07 16:20:47');
INSERT INTO embeddings VALUES(29,29,NULL,'metric_29','Metric: total_absence_days Value: 137.0 days Category: health_wellbeing Context: Sum of all absence days','metric','all-MiniLM-L6-v2','2025-08-07 16:20:47');
INSERT INTO embeddings VALUES(30,30,NULL,'metric_30','Metric: average_absence_days Value: 9.133333333333333 days Category: health_wellbeing Context: Average absence days per person','metric','all-MiniLM-L6-v2','2025-08-07 16:20:47');
INSERT INTO embeddings VALUES(31,31,NULL,'metric_31','Metric: total_annual_salary Value: 268000.0 GBP Category: employment Context: Sum of all annual salaries','metric','all-MiniLM-L6-v2','2025-08-07 16:20:47');
INSERT INTO embeddings VALUES(32,32,NULL,'metric_32','Metric: average_annual_salary Value: 17866.666666666668 GBP Category: employment Context: Average annual salary per person','metric','all-MiniLM-L6-v2','2025-08-07 16:20:47');
INSERT INTO embeddings VALUES(33,33,NULL,'metric_33','Metric: total_carbon_saving Value: 371.50000000000006 kg CO2e Category: environmental_impact Context: Sum of all carbon savings','metric','all-MiniLM-L6-v2','2025-08-07 16:23:57');
INSERT INTO embeddings VALUES(34,34,NULL,'metric_34','Metric: count_reused_or_redeployed Value: 5.0 count Category: environmental_impact Context: Count of reused or redeployed assets','metric','all-MiniLM-L6-v2','2025-08-07 16:23:57');
INSERT INTO embeddings VALUES(35,35,NULL,'metric_35','Metric: count_recycled_assets Value: 7.0 count Category: environmental_impact Context: Count of recycled assets','metric','all-MiniLM-L6-v2','2025-08-07 16:23:58');
INSERT INTO embeddings VALUES(36,36,NULL,'metric_36','Metric: total_courses_completed Value: 104.0 courses Category: employment Context: Sum of all courses completed','metric','all-MiniLM-L6-v2','2025-08-07 16:26:04');
INSERT INTO embeddings VALUES(37,37,NULL,'metric_37','Metric: average_mandatory_training_completion Value: 84.47333333333333 percent Category: employment Context: Average mandatory training completion rate','metric','all-MiniLM-L6-v2','2025-08-07 16:26:04');
INSERT INTO embeddings VALUES(38,38,NULL,'metric_38','Metric: total_social_value_modules_completed Value: 20.0 modules Category: employment Context: Sum of all social value modules completed','metric','all-MiniLM-L6-v2','2025-08-07 16:26:04');
INSERT INTO embeddings VALUES(39,39,NULL,'metric_39','Metric: total_learning_hours Value: 592.0 hours Category: employment Context: Sum of all learning hours','metric','all-MiniLM-L6-v2','2025-08-07 16:26:04');
INSERT INTO embeddings VALUES(40,40,NULL,'metric_40','Metric: certifications_earned_count Value: 12.0 certifications Category: employment Context: Count of certifications earned','metric','all-MiniLM-L6-v2','2025-08-07 16:26:04');
INSERT INTO embeddings VALUES(41,41,NULL,'metric_41','Metric: average_completion_rate Value: 80.14000000000001 percent Category: employment Context: Average completion rate','metric','all-MiniLM-L6-v2','2025-08-07 16:26:04');
INSERT INTO embeddings VALUES(42,42,NULL,'metric_42','Metric: total_charity_donations Value: 2370.55 GBP Category: charitable_giving Context: Sum of all charity donations via payroll','metric','all-MiniLM-L6-v2','2025-08-07 16:26:59');
INSERT INTO embeddings VALUES(43,43,NULL,'metric_43','Metric: average_charity_donation Value: 158.0366666666667 GBP Category: charitable_giving Context: Average charity donation via payroll','metric','all-MiniLM-L6-v2','2025-08-07 16:26:59');
INSERT INTO embeddings VALUES(44,44,NULL,'metric_44','Metric: total_overtime_hours Value: 644.0 hours Category: employment Context: Sum of all overtime hours','metric','all-MiniLM-L6-v2','2025-08-07 16:26:59');
INSERT INTO embeddings VALUES(45,45,NULL,'metric_45','Metric: average_gender_pay_gap Value: -0.09333333333333288 percent Category: employment Context: Average gender pay gap','metric','all-MiniLM-L6-v2','2025-08-07 16:26:59');
INSERT INTO embeddings VALUES(46,46,NULL,'metric_46','Metric: total_gross_pay Value: 382000.0 GBP Category: employment Context: Sum of all gross pay','metric','all-MiniLM-L6-v2','2025-08-07 16:26:59');
INSERT INTO embeddings VALUES(47,47,NULL,'metric_47','Metric: total_pension_contributions Value: 19100.0 GBP Category: employment Context: Sum of all pension contributions','metric','all-MiniLM-L6-v2','2025-08-07 16:26:59');
INSERT INTO embeddings VALUES(48,48,NULL,'metric_48','Metric: total_checkins_completed Value: 325.0 check-ins Category: health_wellbeing Context: Sum of all check-ins completed','metric','all-MiniLM-L6-v2','2025-08-07 16:28:06');
INSERT INTO embeddings VALUES(49,49,NULL,'metric_49','Metric: average_wellbeing_score Value: 6.566666666666667 score Category: health_wellbeing Context: Average wellbeing score','metric','all-MiniLM-L6-v2','2025-08-07 16:28:06');
INSERT INTO embeddings VALUES(50,50,NULL,'metric_50','Metric: unique_charities_unlocked Value: 5.0 charity Category: charitable_giving Context: Count of unique charities unlocked','metric','all-MiniLM-L6-v2','2025-08-07 16:28:06');
INSERT INTO embeddings VALUES(51,51,NULL,'metric_51','Metric: total_care_pathways_followed Value: 36.0 pathways Category: health_wellbeing Context: Sum of all care pathways followed','metric','all-MiniLM-L6-v2','2025-08-07 16:28:06');
INSERT INTO embeddings VALUES(52,52,NULL,'metric_52','Metric: total_spend Value: 419720.37 GBP Category: procurement Context: Sum of all spend','metric','all-MiniLM-L6-v2','2025-08-07 16:29:59');
INSERT INTO embeddings VALUES(53,53,NULL,'metric_53','Metric: proportion_local_suppliers Value: 0.5333333333333333 proportion Category: procurement Context: Proportion of local suppliers','metric','all-MiniLM-L6-v2','2025-08-07 16:29:59');
INSERT INTO embeddings VALUES(54,54,NULL,'metric_54','Metric: proportion_sme_suppliers Value: 0.6 proportion Category: procurement Context: Proportion of SME suppliers','metric','all-MiniLM-L6-v2','2025-08-07 16:29:59');
INSERT INTO embeddings VALUES(55,55,NULL,'metric_55','Metric: proportion_vcse_suppliers Value: 0.4666666666666667 proportion Category: procurement Context: Proportion of VCSE suppliers','metric','all-MiniLM-L6-v2','2025-08-07 16:29:59');
INSERT INTO embeddings VALUES(56,56,NULL,'metric_56','Metric: proportion_ethical_audit_passed Value: 0.6 proportion Category: procurement Context: Proportion of suppliers that passed the ethical audit','metric','all-MiniLM-L6-v2','2025-08-07 16:29:59');
INSERT INTO embeddings VALUES(57,57,NULL,'metric_57','Metric: average_inclusion_score Value: 6.866666666666666 score Category: employment Context: Average inclusion score','metric','all-MiniLM-L6-v2','2025-08-07 16:32:24');
INSERT INTO embeddings VALUES(58,58,NULL,'metric_58','Metric: average_wellbeing_perception_score Value: 7.466666666666667 score Category: health_wellbeing Context: Average wellbeing perception score','metric','all-MiniLM-L6-v2','2025-08-07 16:32:24');
INSERT INTO embeddings VALUES(59,59,NULL,'metric_59','Metric: average_purpose_alignment_score Value: 5.4 score Category: employment Context: Average purpose alignment score','metric','all-MiniLM-L6-v2','2025-08-07 16:32:24');
INSERT INTO embeddings VALUES(60,60,NULL,'metric_60','Metric: average_manager_trust_score Value: 7.466666666666667 score Category: employment Context: Average manager trust score','metric','all-MiniLM-L6-v2','2025-08-07 16:32:24');
INSERT INTO embeddings VALUES(61,61,NULL,'metric_61','Metric: average_esg_awareness_score Value: 6.4 score Category: environmental_impact Context: Average ESG awareness score','metric','all-MiniLM-L6-v2','2025-08-07 16:32:24');
INSERT INTO embeddings VALUES(62,62,NULL,'metric_62','Metric: total_charity_donations Value: 2370.55 GBP Category: charitable_giving Context: Sum of all charity donations via payroll','metric','all-MiniLM-L6-v2','2025-08-07 23:07:15');
INSERT INTO embeddings VALUES(63,63,NULL,'metric_63','Metric: average_charity_donation Value: 158.0366666666667 GBP Category: charitable_giving Context: Average charity donation via payroll','metric','all-MiniLM-L6-v2','2025-08-07 23:07:15');
INSERT INTO embeddings VALUES(64,64,NULL,'metric_64','Metric: total_gross_pay Value: 382000.0 GBP Category: employment Context: Sum of all gross pay','metric','all-MiniLM-L6-v2','2025-08-07 23:07:15');
INSERT INTO embeddings VALUES(65,65,NULL,'metric_65','Metric: total_overtime_hours Value: 644.0 hours Category: employment Context: Sum of all overtime hours','metric','all-MiniLM-L6-v2','2025-08-07 23:07:15');
INSERT INTO embeddings VALUES(66,66,NULL,'metric_66','Metric: average_gender_pay_gap Value: -0.09333333333333288 percent Category: employment Context: Average gender pay gap','metric','all-MiniLM-L6-v2','2025-08-07 23:07:15');
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('frameworks',5);
INSERT INTO sqlite_sequence VALUES('sources',13);
INSERT INTO sqlite_sequence VALUES('impact_metrics',66);
INSERT INTO sqlite_sequence VALUES('embeddings',66);
CREATE INDEX idx_impact_metrics_category 
            ON impact_metrics (metric_category)
        ;
CREATE INDEX idx_impact_metrics_name 
            ON impact_metrics (metric_name)
        ;
CREATE INDEX idx_impact_metrics_verification 
            ON impact_metrics (verification_status)
        ;
COMMIT;
